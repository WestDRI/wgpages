#!/usr/bin/env python
import numpy as np
from tqdm import tqdm
import time
from scipy.special import lpmv

nlat, nr, nlon = 500, 300, 800

latitude = np.linspace(-90, 90, nlat)
radius = np.linspace(3485, 6371, nr)
longitude = np.linspace(0, 360, nlon)

# spherical velocity components: use Legendre Polynomials to set values
vlat = lpmv(0,3,latitude/90).reshape(nlat,1,1) + np.linspace(0,0,nr).reshape(nr,1) + np.linspace(0,0,nlon)
vrad = np.linspace(0,0,nlat).reshape(nlat,1,1) + lpmv(0,3,(radius-4928)/1443).reshape(nr,1) + np.linspace(0,0,nlon)
vlon = np.linspace(0,0,nlat).reshape(nlat,1,1) + np.linspace(0,0,nr).reshape(nr,1) + lpmv(0,2,longitude/180-1.)

# Cartesian components
vx = np.zeros((nlat,nr,nlon))
vy = np.zeros((nlat,nr,nlon))
vz = np.zeros((nlat,nr,nlon))

mode = 5
# 1 - 29m
# 2 - 3m
# 3 - 2.51s
# 4 - 1.25s, 1392X speedup
# 5 - 2.52s

if mode == 1:
    start = time.time()
    for i in tqdm(range(nlat)):
        for j in range(nr):
            for k in range(nlon):
                vx[i,j,k] = - np.sin(np.radians(longitude[k]))*vlon[i,j,k] \
                  - np.sin(np.radians(latitude[i]))*np.cos(np.radians(longitude[k]))*vlat[i,j,k] \
                  + np.cos(np.radians(latitude[i]))*np.cos(np.radians(longitude[k]))*vrad[i,j,k]
                vy[i,j,k] = np.cos(np.radians(longitude[k]))*vlon[i,j,k] \
                  - np.sin(np.radians(latitude[i]))*np.sin(np.radians(longitude[k]))*vlat[i,j,k] \
                  + np.cos(np.radians(latitude[i]))*np.sin(np.radians(longitude[k]))*vrad[i,j,k]
                vz[i,j,k] = np.cos(np.radians(latitude[i]))*vlat[i,j,k] \
                  + np.sin(np.radians(latitude[i]))*vrad[i,j,k]
    finish = time.time()

slat = np.sin(np.radians(latitude))
clat = np.cos(np.radians(latitude))
slon = np.sin(np.radians(longitude))
clon = np.cos(np.radians(longitude))

if mode == 2:
    start = time.time()
    for i in tqdm(range(nlat)):
        for j in range(nr):
            for k in range(nlon):
                vx[i,j,k] = - slon[k]*vlon[i,j,k] - slat[i]*clon[k]*vlat[i,j,k] + clat[i]*clon[k]*vrad[i,j,k]
                vy[i,j,k] = clon[k]*vlon[i,j,k] - slat[i]*slon[k]*vlat[i,j,k] + clat[i]*slon[k]*vrad[i,j,k]
                vz[i,j,k] = clat[i]*vlat[i,j,k] + slat[i]*vrad[i,j,k]
    finish = time.time()

if mode == 3:
    start = time.time()
    for i in tqdm(range(nlat)):
        for j in range(nr):
            vx[i,j,:] = - slon[:]*vlon[i,j,:] - slat[i]*clon[:]*vlat[i,j,:] + clat[i]*clon[:]*vrad[i,j,:]
            vy[i,j,:] = clon[:]*vlon[i,j,:] - slat[i]*slon[:]*vlat[i,j,:] + clat[i]*slon[:]*vrad[i,j,:]
            vz[i,j,:] = clat[i]*vlat[i,j,:] + slat[i]*vrad[i,j,:]
    finish = time.time()

if mode == 4:
    start = time.time()
    for i in tqdm(range(nlat)):
        vx[i,:,:] = - slon[:]*vlon[i,:,:] - slat[i]*clon[:]*vlat[i,:,:] + clat[i]*clon[:]*vrad[i,:,:]
        vy[i,:,:] = clon[:]*vlon[i,:,:] - slat[i]*slon[:]*vlat[i,:,:] + clat[i]*slon[:]*vrad[i,:,:]
        vz[i,:,:] = clat[i]*vlat[i,:,:] + slat[i]*vrad[i,:,:]
    finish = time.time()

if mode == 5:
    start = time.time()
    clatReshaped = clat.reshape(nlat,1,1)
    slatReshaped = slat.reshape(nlat,1,1)
    vx = - slon*vlon - slatReshaped*clon*vlat + clatReshaped*clon*vrad
    vy = clon*vlon - slatReshaped*slon*vlat + clatReshaped*slon*vrad
    vz = clatReshaped*vlat + slatReshaped*vrad
    finish = time.time()

print("It took", finish - start, "seconds")
